package day02;

public class JavaDemo {


    public static void m1(String name, String ...arg) {

    }

    public static void main(String[] args) {
        m1("xx", "x", "b", "c");
    }
}
