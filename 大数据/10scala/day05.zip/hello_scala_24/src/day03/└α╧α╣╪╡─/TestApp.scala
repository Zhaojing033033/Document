package day03.类相关的

object TestApp extends App{

//    private val teacher = new Teacher("辉辉", 26)
//    teacher.name = "行行"
//    println(teacher.name)

    //teacher.age = 30

//    println(teacher.name, teacher.age)

//    private val ttTeacher = new Teacher("TT", 35, "男", "XX")
//    println(ttTeacher.prov)



}
