package day03

trait Animal {

    def run()

}
