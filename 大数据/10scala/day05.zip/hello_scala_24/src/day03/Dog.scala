package day03

trait Dog {

    val name: String = "dog"

    def run()

}
