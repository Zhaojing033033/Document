package day03.class24

import day03.类相关的.Teacher

object Class24 extends App{

//    private val hatanoTeacher = new Teacher("hatano", 19)
//    println(hatanoTeacher.name)
}
