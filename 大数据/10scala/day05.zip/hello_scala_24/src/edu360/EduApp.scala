package edu360

//import day03.Teacher

object EduApp extends App{

//    private val hatanoTeacher = new Teacher("hatano", 19)
//    println(hatanoTeacher.name)

}
