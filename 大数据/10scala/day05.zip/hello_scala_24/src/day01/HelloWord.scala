package day01

object HelloWord {

    def main(args: Array[String]): Unit = {

        //println("hello "+args(0))

        // yield

        (a: Int, b: Int) => a + b



    }



}
