package day01;

public interface IOperate {

    public Integer caoZuo(Integer ele);

}
